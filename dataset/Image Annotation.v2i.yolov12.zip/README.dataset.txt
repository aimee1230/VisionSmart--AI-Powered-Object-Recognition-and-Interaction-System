# Image Annotation > 2025-03-23 6:43am
https://universe.roboflow.com/abc-m0ngq/image-annotation-xvorl

Provided by a Roboflow user
License: CC BY 4.0

